var searchData=
[
  ['takedamage_200',['TakeDamage',['../class_enemy.html#a12672c4031953055b32228f1ff4d8d7a',1,'Enemy']]]
];
