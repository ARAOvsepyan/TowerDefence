var searchData=
[
  ['lives_232',['lives',['../class_lives.html#a33fefc2aec505fe793864a75a3608f1a',1,'Lives.lives()'],['../class_stats.html#aaba4e93d3eb2afdd405fc2b20467a40c',1,'Stats.Lives()']]]
];
