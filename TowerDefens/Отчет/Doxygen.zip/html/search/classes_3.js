var searchData=
[
  ['gamemanager_134',['GameManager',['../class_game_manager.html',1,'']]],
  ['gameover_135',['GameOver',['../class_game_over.html',1,'']]]
];
