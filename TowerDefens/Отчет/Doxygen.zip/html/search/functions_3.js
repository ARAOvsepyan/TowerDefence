var searchData=
[
  ['damage_170',['Damage',['../class_bullet.html#ae96a53f82b15b06ec472fb29462926a7',1,'Bullet']]],
  ['die_171',['Die',['../class_enemy.html#ac8eb629ba2895e86aa7f940334c94c02',1,'Enemy']]]
];
