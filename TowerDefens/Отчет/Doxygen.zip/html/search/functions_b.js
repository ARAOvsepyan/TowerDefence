var searchData=
[
  ['reachtheend_188',['ReachTheEnd',['../class_enemy.html#ab62a57ae3f602fb7cee9869e815e43e5',1,'Enemy']]],
  ['restatr_189',['Restatr',['../class_game_over.html#a5e79ad807c660890de105f61d5ed8ea8',1,'GameOver']]]
];
