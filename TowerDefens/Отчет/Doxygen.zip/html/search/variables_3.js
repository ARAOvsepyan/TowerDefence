var searchData=
[
  ['damage_220',['damage',['../class_bullet.html#a30560d42f8615865e287def189618e31',1,'Bullet']]],
  ['domovement_221',['doMovement',['../class_camera_effect.html#a1cce82787e2e1734137230694640c6e9',1,'CameraEffect']]]
];
