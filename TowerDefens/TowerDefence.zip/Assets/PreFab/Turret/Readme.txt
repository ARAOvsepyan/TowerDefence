Fatty Poly Turret Free. (2019/9/29 - by Fatty War, id3644@gmail.com)

This is a turret pack of mortar and cannon type.
Is a polygon art pack, the perfect bundle of Ranged Weapon, greatly optimized and mobile friendly.

The full version is ready : http://u3d.as/1DsT

Features:
This is a demo version of fatty poly turret.
- 2 types of turret. (cannon, mortar)
- Each turret has 4-step. (*full version only)
- 3 different Body colours (*full version only)
- Part Modeling for 2Axis
- All turrets used only one material & texture. Each turret has its own UV for each color.

*Note). Inside the turret prefab is a shot position and shot effect.
If you don't need a shot position and a shot effect, remove it. (ShootPoint, FireFx)

*If you have any questions or suggestions about the assets, please contact me.(id3644@gmail.com)

Thank you for your purchase.