var class_won =
[
    [ "Exit", "class_won.html#a274d9994a5b104df1260094b00072cca", null ],
    [ "NextLevel", "class_won.html#ad5d7964fee8097973f999b433c877dba", null ]
];