var class_stats =
[
    [ "Start", "class_stats.html#ab7122da0fafe848b0eb99729c0f5db44", null ],
    [ "basicLives", "class_stats.html#a8c773f5cab3308aef550b51d0a8fcae2", null ],
    [ "basicMoney", "class_stats.html#a4d4f5ba7d527cbcb1228d012bb9f7c86", null ],
    [ "countOfWaves", "class_stats.html#a30ce4c10d307dedad321cac92fa70b32", null ],
    [ "Lives", "class_stats.html#aaba4e93d3eb2afdd405fc2b20467a40c", null ],
    [ "Money", "class_stats.html#a505666dabe0a4e0b78f0ec70fbb579e2", null ]
];