var class_game_over =
[
    [ "Exit", "class_game_over.html#a4ce4e48ad15fb798d337ef2c5c3cbc61", null ],
    [ "OnEnable", "class_game_over.html#a64ac35c8033f6511c91c5c9d0de7e626", null ],
    [ "Restatr", "class_game_over.html#a5e79ad807c660890de105f61d5ed8ea8", null ],
    [ "_countOfWaves", "class_game_over.html#a40de44e9309f54737c48e355b2f7446e", null ]
];