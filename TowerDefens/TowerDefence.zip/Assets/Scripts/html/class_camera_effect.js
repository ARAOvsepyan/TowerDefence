var class_camera_effect =
[
    [ "Update", "class_camera_effect.html#a8fa8c9f199e5c0b13ecfd9e8dbb60f8f", null ],
    [ "BorderLenght", "class_camera_effect.html#aa99b435836c7783f8fa0dbd4c0ad242d", null ],
    [ "doMovement", "class_camera_effect.html#a1cce82787e2e1734137230694640c6e9", null ],
    [ "maxY", "class_camera_effect.html#a4323d8df2d36c64fee1e145892b99011", null ],
    [ "minY", "class_camera_effect.html#ac2e72c0fd523286070f09db830666be7", null ],
    [ "speed", "class_camera_effect.html#aa5b6a6e10d062f58cd7c5ca49ce16103", null ]
];