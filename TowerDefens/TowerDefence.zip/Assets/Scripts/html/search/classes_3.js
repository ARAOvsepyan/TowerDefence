var searchData=
[
  ['gamemanager_135',['GameManager',['../class_game_manager.html',1,'']]],
  ['gameover_136',['GameOver',['../class_game_over.html',1,'']]]
];
