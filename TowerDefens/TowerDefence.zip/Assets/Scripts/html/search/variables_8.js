var searchData=
[
  ['instance_232',['instance',['../class_build.html#a49eddc3dd0b1a2f9ab44eb85d94ad527',1,'Build']]],
  ['isupgraded_233',['isUpgraded',['../class_node.html#ac6c09440d162a5a4b548993a147c121b',1,'Node']]]
];
