var searchData=
[
  ['damage_28',['Damage',['../class_bullet.html#ae96a53f82b15b06ec472fb29462926a7',1,'Bullet.Damage(Transform enemy)'],['../class_bullet.html#a30560d42f8615865e287def189618e31',1,'Bullet.damage()']]],
  ['die_29',['Die',['../class_enemy.html#ac8eb629ba2895e86aa7f940334c94c02',1,'Enemy']]],
  ['domovement_30',['doMovement',['../class_camera_effect.html#a1cce82787e2e1734137230694640c6e9',1,'CameraEffect']]]
];
