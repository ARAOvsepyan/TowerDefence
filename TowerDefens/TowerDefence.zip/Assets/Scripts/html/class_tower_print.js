var class_tower_print =
[
    [ "GetSellCost", "class_tower_print.html#a3587bd5d8bdb57b3fae4eb762d92bd03", null ],
    [ "cost", "class_tower_print.html#ad354a5549d6e6fba385b088dc9b2553f", null ],
    [ "prefab", "class_tower_print.html#ad92d4b164b07f3a71a7cb76949f8a6a1", null ],
    [ "upgradeCost", "class_tower_print.html#a629fae3d59fcdc7628bb499d134c6359", null ],
    [ "upgradedPrefab", "class_tower_print.html#aed8d108af65e5406942006eccfb651db", null ]
];