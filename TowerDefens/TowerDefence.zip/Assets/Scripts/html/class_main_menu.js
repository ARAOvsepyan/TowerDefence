var class_main_menu =
[
    [ "Play", "class_main_menu.html#a18b84d06aaaeb1086349846809d31ab3", null ],
    [ "Quit", "class_main_menu.html#a73c5c7c17c45d592320d9c31eadc0e33", null ]
];