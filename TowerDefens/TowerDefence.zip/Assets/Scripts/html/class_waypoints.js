var class_waypoints =
[
    [ "Awake", "class_waypoints.html#a75d127f37f7f5558680ccf698145109c", null ],
    [ "points", "class_waypoints.html#a01cbb001d115c9234d20137a5d49dcfe", null ]
];