var class_lives =
[
    [ "Update", "class_lives.html#aa5a72eef22712bf22a42332390f30f9d", null ],
    [ "lives", "class_lives.html#a33fefc2aec505fe793864a75a3608f1a", null ]
];