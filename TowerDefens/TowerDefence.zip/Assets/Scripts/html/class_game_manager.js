var class_game_manager =
[
    [ "GameOver", "class_game_manager.html#a8d69157cb6b97eabeff2374d8e9adeaf", null ],
    [ "Start", "class_game_manager.html#a5ccfacd027ad08eeb4ff1f25a7f59c98", null ],
    [ "Update", "class_game_manager.html#a44c79b205dec16bfe650e21259860c5b", null ],
    [ "Won", "class_game_manager.html#ae9c6ba059e06645f2d714ed8320e548a", null ],
    [ "_GameOver", "class_game_manager.html#ab8734e8a18f7f87d51dfd20a8ca0eb01", null ],
    [ "_Won", "class_game_manager.html#a69268dfa7f9594ff2af173717f897f80", null ],
    [ "gameOver", "class_game_manager.html#af07b7a1aadb8225e40190b2a2a1adef1", null ],
    [ "won", "class_game_manager.html#ad277dc3ee476bf38ad2973106407824c", null ]
];